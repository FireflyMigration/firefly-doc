﻿using ENV.Remoting;
namespace Northwind.Server
{
    public class Services : System.Web.UI.Page 
    {
        protected void Page_Load(object sender, System.EventArgs e)
        {
            ServerInstance.Process();
        }
        static HttpApplicationServer ServerInstance = new HttpApplicationServer(() => Northwind.Application.Instance);
    }
}
