﻿namespace Northwind.Server
{
    public class Request : System.Web.UI.Page 
    {
        protected void Page_Load(object sender, System.EventArgs e)
        {
            Northwind.Application.Instance.ProcessWebRequest();
        }
    }
}
