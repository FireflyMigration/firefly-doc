﻿using System.Web;
namespace Northwind.Server.App_Start
{
    class AppServerConfig
    {
        public static void Register()
        {
            ENV.Common.SuppressDialogs();
            ENV.Data.DataProvider.ConnectionManager.UseConnectionPool = true;
            System.Environment.CurrentDirectory = HttpContext.Current.Server.MapPath("");
            Northwind.Program.Init(new string[] { "/ini=Northwind.Server.ini", "@additions.ini" });
            ENV.ApplicationControllerBase.SetRootApplicationFactory(() => Northwind.Application.Instance);
        }
    }
}
