﻿namespace Northwind.Server
{
    public class Global : System.Web.HttpApplication 
    {
        protected void Application_Start(object sender, System.EventArgs e)
        {
            App_Start.AppServerConfig.Register();
        }
        protected void Application_EndRequest(object sender, System.EventArgs e)
        {
            Firefly.Box.Context.Current.Dispose();
        }
    }
}
