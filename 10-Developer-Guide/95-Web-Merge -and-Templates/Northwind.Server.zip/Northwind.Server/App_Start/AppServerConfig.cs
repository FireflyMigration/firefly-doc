﻿using ENV;
using System.Web;
namespace Northwind.Server.App_Start
{
    class AppServerConfig
    {
        public static void Register()
        {
            Common.SuppressDialogs();
            ENV.Data.DataProvider.ConnectionManager.UseConnectionPool = true;
            UserSettings.Version10Compatible = true;
            Firefly.Box.Text.StopProcessingFormatOnCharF = true;
            ENV.Data.DateColumn.GlobalDefault = new Firefly.Box.Date(1901,1,1);
            UserSettings.LoadIniFile(HttpContext.Current.Server.MapPath("Northwind.Server.ini"));
            System.Environment.CurrentDirectory = HttpContext.Current.Server.MapPath("");
            UserSettings.ReadIniAdditionsFile(HttpContext.Current.Server.MapPath("additions.ini"));
            ApplicationControllerBase.SetRootApplicationFactory(() => Northwind.Application.Instance);
        }
    }
}
