﻿using Firefly.Box;
using ENV.Data;
namespace Northwind.Models
{
    /// <summary>ExchangeRates(E#8)</summary>
    public class ExchangeRates : Entity 
    {
        #region Columns
        [PrimaryKey]
        public readonly TextColumn Currency = new TextColumn("Currency", "3U");
        [PrimaryKey]
        public readonly DateColumn EffectiveDate = new DateColumn("EffectiveDate") { Storage = new ENV.Data.Storage.DateTimeDateStorage() };
        public readonly NumberColumn Rate = new NumberColumn("Rate", "2.4");
        #endregion
        #region Indexes
        /// <summary>By Date (#1)</summary>
        public readonly Index SortByDate = new Index { Caption = "By Date", Name = "By_Date", AutoCreate = true, Unique = true };
        #endregion
        public ExchangeRates() : base("ExchangeRate", "ExchangeRates", Northwind.Shared.DataSources.Northwind1)
        {
            AutoCreateTable = true;
            InitializeIndexes();
        }
        void InitializeIndexes()
        {
            SortByDate.Add(Currency, EffectiveDate);
        }
    }
}
