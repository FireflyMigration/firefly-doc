﻿using Firefly.Box;
using ENV.Data;
namespace Northwind.Models
{
    /// <summary>CategorySales(E#9)</summary>
    public class CategorySales : Entity 
    {
        #region Columns
        [PrimaryKey]
        public readonly NumberColumn Year = new NumberColumn("Year", "4P0");
        [PrimaryKey]
        public readonly NumberColumn CategoryID = new NumberColumn("CategoryID", "3");
        public readonly Types.Amount Jan = new Types.Amount { Caption = "Jan", Name = "Jan" };
        public readonly Types.Amount Feb = new Types.Amount { Caption = "Feb", Name = "Feb" };
        public readonly Types.Amount Mar = new Types.Amount { Caption = "Mar", Name = "Mar" };
        public readonly Types.Amount Apr = new Types.Amount { Caption = "Apr", Name = "Apr" };
        public readonly Types.Amount May = new Types.Amount { Caption = "May", Name = "May" };
        public readonly Types.Amount Jun = new Types.Amount { Caption = "Jun", Name = "Jun" };
        public readonly Types.Amount Jul = new Types.Amount { Caption = "Jul", Name = "Jul" };
        public readonly Types.Amount Aug = new Types.Amount { Caption = "Aug", Name = "Aug" };
        public readonly Types.Amount Sep = new Types.Amount { Caption = "Sep", Name = "Sep" };
        public readonly Types.Amount Oct = new Types.Amount { Caption = "Oct", Name = "Oct" };
        public readonly Types.Amount Nov = new Types.Amount { Caption = "Nov", Name = "Nov" };
        public readonly Types.Amount Dec = new Types.Amount { Caption = "Dec", Name = "Dec" };
        #endregion
        #region Indexes
        /// <summary>By Year and Category (#1)</summary>
        public readonly Index SortByYearAndCategory = new Index { Caption = "By Year and Category", Name = "By_Year_and_Prod", AutoCreate = true, Unique = true };
        #endregion
        public CategorySales() : base("CategorySales", Northwind.Shared.DataSources.Northwind1)
        {
            AutoCreateTable = true;
            InitializeIndexes();
        }
        void InitializeIndexes()
        {
            SortByYearAndCategory.Add(Year, CategoryID);
        }
    }
}
