﻿using Firefly.Box.UI;
using System.Drawing;
using Firefly.Box.UI.Advanced;
using Firefly.Box;
using Northwind.Shared.Theme;
namespace Northwind.Views
{
    /// <summary>Browse - CategorySales(P#13.3)</summary>
    partial class CategorySalesInfoBrowse_CategorySales : Northwind.Shared.Theme.Controls.CompatibleForm 
    {
        CategorySalesInfo.Browse_CategorySales _controller;
        internal CategorySalesInfoBrowse_CategorySales(CategorySalesInfo.Browse_CategorySales controller)
        {
            _controller = controller;
            InitializeComponent();
        }
    }
}
