﻿using Firefly.Box.UI;
using System.Drawing;
using Firefly.Box.UI.Advanced;
using Firefly.Box;
using Northwind.Shared.Theme;
namespace Northwind.Views
{
    partial class CategorySalesInfoBrowse_CategorySales
    {
        System.ComponentModel.IContainer components;
        Shared.Theme.Controls.CompatibleGrid grd;
        Shared.Theme.Controls.CompatibleGridColumn gclYear;
        Shared.Theme.Controls.CompatibleGridColumn gclCategoryID;
        Shared.Theme.Controls.CompatibleGridColumn gclJan;
        Shared.Theme.Controls.CompatibleGridColumn gclFeb;
        Shared.Theme.Controls.CompatibleGridColumn gclMar;
        Shared.Theme.Controls.CompatibleGridColumn gclApr;
        Shared.Theme.Controls.CompatibleGridColumn gclMay;
        Shared.Theme.Controls.CompatibleGridColumn gclJun;
        Shared.Theme.Controls.CompatibleGridColumn gclJul;
        Shared.Theme.Controls.CompatibleGridColumn gclAug;
        Shared.Theme.Controls.CompatibleGridColumn gclSep;
        Shared.Theme.Controls.CompatibleGridColumn gclOct;
        Shared.Theme.Controls.CompatibleGridColumn gclNov;
        Shared.Theme.Controls.CompatibleGridColumn gclDec;
        Shared.Theme.Controls.CompatibleTextBox txtCategorySales_Year;
        Shared.Theme.Controls.CompatibleTextBox txtCategorySales_CategoryID;
        Shared.Theme.Controls.CompatibleTextBox txtCategorySales_Jan;
        Shared.Theme.Controls.CompatibleTextBox txtCategorySales_Feb;
        Shared.Theme.Controls.CompatibleTextBox txtCategorySales_Mar;
        Shared.Theme.Controls.CompatibleTextBox txtCategorySales_Apr;
        Shared.Theme.Controls.CompatibleTextBox txtCategorySales_May;
        Shared.Theme.Controls.CompatibleTextBox txtCategorySales_Jun;
        Shared.Theme.Controls.CompatibleTextBox txtCategorySales_Jul;
        Shared.Theme.Controls.CompatibleTextBox txtCategorySales_Aug;
        Shared.Theme.Controls.CompatibleTextBox txtCategorySales_Sep;
        Shared.Theme.Controls.CompatibleTextBox txtCategorySales_Oct;
        Shared.Theme.Controls.CompatibleTextBox txtCategorySales_Nov;
        Shared.Theme.Controls.CompatibleTextBox txtCategorySales_Dec;
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }
        void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            this.grd = new Northwind.Shared.Theme.Controls.CompatibleGrid();
            this.gclYear = new Northwind.Shared.Theme.Controls.CompatibleGridColumn();
            this.txtCategorySales_Year = new Northwind.Shared.Theme.Controls.CompatibleTextBox();
            this.gclCategoryID = new Northwind.Shared.Theme.Controls.CompatibleGridColumn();
            this.txtCategorySales_CategoryID = new Northwind.Shared.Theme.Controls.CompatibleTextBox();
            this.gclJan = new Northwind.Shared.Theme.Controls.CompatibleGridColumn();
            this.txtCategorySales_Jan = new Northwind.Shared.Theme.Controls.CompatibleTextBox();
            this.gclFeb = new Northwind.Shared.Theme.Controls.CompatibleGridColumn();
            this.txtCategorySales_Feb = new Northwind.Shared.Theme.Controls.CompatibleTextBox();
            this.gclMar = new Northwind.Shared.Theme.Controls.CompatibleGridColumn();
            this.txtCategorySales_Mar = new Northwind.Shared.Theme.Controls.CompatibleTextBox();
            this.gclApr = new Northwind.Shared.Theme.Controls.CompatibleGridColumn();
            this.txtCategorySales_Apr = new Northwind.Shared.Theme.Controls.CompatibleTextBox();
            this.gclMay = new Northwind.Shared.Theme.Controls.CompatibleGridColumn();
            this.txtCategorySales_May = new Northwind.Shared.Theme.Controls.CompatibleTextBox();
            this.gclJun = new Northwind.Shared.Theme.Controls.CompatibleGridColumn();
            this.txtCategorySales_Jun = new Northwind.Shared.Theme.Controls.CompatibleTextBox();
            this.gclJul = new Northwind.Shared.Theme.Controls.CompatibleGridColumn();
            this.txtCategorySales_Jul = new Northwind.Shared.Theme.Controls.CompatibleTextBox();
            this.gclAug = new Northwind.Shared.Theme.Controls.CompatibleGridColumn();
            this.txtCategorySales_Aug = new Northwind.Shared.Theme.Controls.CompatibleTextBox();
            this.gclSep = new Northwind.Shared.Theme.Controls.CompatibleGridColumn();
            this.txtCategorySales_Sep = new Northwind.Shared.Theme.Controls.CompatibleTextBox();
            this.gclOct = new Northwind.Shared.Theme.Controls.CompatibleGridColumn();
            this.txtCategorySales_Oct = new Northwind.Shared.Theme.Controls.CompatibleTextBox();
            this.gclNov = new Northwind.Shared.Theme.Controls.CompatibleGridColumn();
            this.txtCategorySales_Nov = new Northwind.Shared.Theme.Controls.CompatibleTextBox();
            this.gclDec = new Northwind.Shared.Theme.Controls.CompatibleGridColumn();
            this.txtCategorySales_Dec = new Northwind.Shared.Theme.Controls.CompatibleTextBox();
            this.grd.SuspendLayout();
            this.gclYear.SuspendLayout();
            this.gclCategoryID.SuspendLayout();
            this.gclJan.SuspendLayout();
            this.gclFeb.SuspendLayout();
            this.gclMar.SuspendLayout();
            this.gclApr.SuspendLayout();
            this.gclMay.SuspendLayout();
            this.gclJun.SuspendLayout();
            this.gclJul.SuspendLayout();
            this.gclAug.SuspendLayout();
            this.gclSep.SuspendLayout();
            this.gclOct.SuspendLayout();
            this.gclNov.SuspendLayout();
            this.gclDec.SuspendLayout();
            this.SuspendLayout();
            
            // grd
            
            this.grd.AdvancedAnchor = new Firefly.Box.UI.AdvancedAnchor(0, 100, 0, 100);
            this.grd.Controls.Add(this.gclYear);
            this.grd.Controls.Add(this.gclCategoryID);
            this.grd.Controls.Add(this.gclJan);
            this.grd.Controls.Add(this.gclFeb);
            this.grd.Controls.Add(this.gclMar);
            this.grd.Controls.Add(this.gclApr);
            this.grd.Controls.Add(this.gclMay);
            this.grd.Controls.Add(this.gclJun);
            this.grd.Controls.Add(this.gclJul);
            this.grd.Controls.Add(this.gclAug);
            this.grd.Controls.Add(this.gclSep);
            this.grd.Controls.Add(this.gclOct);
            this.grd.Controls.Add(this.gclNov);
            this.grd.Controls.Add(this.gclDec);
            this.grd.Location = new System.Drawing.Point(10, 13);
            this.grd.Name = "grd";
            this.grd.RowHeight = 21;
            this.grd.Size = new System.Drawing.Size(1060, 296);
            
            // gclYear
            
            this.gclYear.AllowSort = true;
            this.gclYear.Controls.Add(this.txtCategorySales_Year);
            this.gclYear.Name = "gclYear";
            this.gclYear.Text = "Year";
            this.gclYear.Width = 37;
            
            // txtCategorySales_Year
            
            this.txtCategorySales_Year.AdvancedAnchor = new Firefly.Box.UI.AdvancedAnchor(0, 100, 0, 0);
            this.txtCategorySales_Year.Alignment = System.Drawing.ContentAlignment.MiddleRight;
            this.txtCategorySales_Year.Location = new System.Drawing.Point(3, 2);
            this.txtCategorySales_Year.Name = "txtCategorySales_Year";
            this.txtCategorySales_Year.Size = new System.Drawing.Size(28, 17);
            this.txtCategorySales_Year.Style = Firefly.Box.UI.ControlStyle.Flat;
            this.txtCategorySales_Year.Tag = "Year";
            this.txtCategorySales_Year.Data = this._controller.CategorySales.Year;
            
            // gclCategoryID
            
            this.gclCategoryID.Controls.Add(this.txtCategorySales_CategoryID);
            this.gclCategoryID.Name = "gclCategoryID";
            this.gclCategoryID.Text = "CategoryID";
            this.gclCategoryID.Width = 58;
            
            // txtCategorySales_CategoryID
            
            this.txtCategorySales_CategoryID.AdvancedAnchor = new Firefly.Box.UI.AdvancedAnchor(0, 100, 0, 0);
            this.txtCategorySales_CategoryID.Alignment = System.Drawing.ContentAlignment.MiddleRight;
            this.txtCategorySales_CategoryID.Location = new System.Drawing.Point(2, 2);
            this.txtCategorySales_CategoryID.Name = "txtCategorySales_CategoryID";
            this.txtCategorySales_CategoryID.Size = new System.Drawing.Size(23, 17);
            this.txtCategorySales_CategoryID.Style = Firefly.Box.UI.ControlStyle.Flat;
            this.txtCategorySales_CategoryID.Tag = "CategoryID";
            this.txtCategorySales_CategoryID.Data = this._controller.CategorySales.CategoryID;
            
            // gclJan
            
            this.gclJan.Controls.Add(this.txtCategorySales_Jan);
            this.gclJan.Name = "gclJan";
            this.gclJan.Text = "Jan";
            this.gclJan.Width = 79;
            
            // txtCategorySales_Jan
            
            this.txtCategorySales_Jan.AdvancedAnchor = new Firefly.Box.UI.AdvancedAnchor(0, 100, 0, 0);
            this.txtCategorySales_Jan.Alignment = System.Drawing.ContentAlignment.MiddleRight;
            this.txtCategorySales_Jan.Location = new System.Drawing.Point(2, 2);
            this.txtCategorySales_Jan.Name = "txtCategorySales_Jan";
            this.txtCategorySales_Jan.Size = new System.Drawing.Size(70, 17);
            this.txtCategorySales_Jan.Style = Firefly.Box.UI.ControlStyle.Flat;
            this.txtCategorySales_Jan.Tag = "Jan";
            this.txtCategorySales_Jan.Data = this._controller.CategorySales.Jan;
            
            // gclFeb
            
            this.gclFeb.Controls.Add(this.txtCategorySales_Feb);
            this.gclFeb.Name = "gclFeb";
            this.gclFeb.Text = "Feb";
            this.gclFeb.Width = 78;
            
            // txtCategorySales_Feb
            
            this.txtCategorySales_Feb.AdvancedAnchor = new Firefly.Box.UI.AdvancedAnchor(0, 100, 0, 0);
            this.txtCategorySales_Feb.Alignment = System.Drawing.ContentAlignment.MiddleRight;
            this.txtCategorySales_Feb.Location = new System.Drawing.Point(2, 2);
            this.txtCategorySales_Feb.Name = "txtCategorySales_Feb";
            this.txtCategorySales_Feb.Size = new System.Drawing.Size(70, 17);
            this.txtCategorySales_Feb.Style = Firefly.Box.UI.ControlStyle.Flat;
            this.txtCategorySales_Feb.Tag = "Feb";
            this.txtCategorySales_Feb.Data = this._controller.CategorySales.Feb;
            
            // gclMar
            
            this.gclMar.Controls.Add(this.txtCategorySales_Mar);
            this.gclMar.Name = "gclMar";
            this.gclMar.Text = "Mar";
            this.gclMar.Width = 79;
            
            // txtCategorySales_Mar
            
            this.txtCategorySales_Mar.AdvancedAnchor = new Firefly.Box.UI.AdvancedAnchor(0, 100, 0, 0);
            this.txtCategorySales_Mar.Alignment = System.Drawing.ContentAlignment.MiddleRight;
            this.txtCategorySales_Mar.Location = new System.Drawing.Point(2, 2);
            this.txtCategorySales_Mar.Name = "txtCategorySales_Mar";
            this.txtCategorySales_Mar.Size = new System.Drawing.Size(70, 17);
            this.txtCategorySales_Mar.Style = Firefly.Box.UI.ControlStyle.Flat;
            this.txtCategorySales_Mar.Tag = "Mar";
            this.txtCategorySales_Mar.Data = this._controller.CategorySales.Mar;
            
            // gclApr
            
            this.gclApr.Controls.Add(this.txtCategorySales_Apr);
            this.gclApr.Name = "gclApr";
            this.gclApr.Text = "Apr";
            this.gclApr.Width = 79;
            
            // txtCategorySales_Apr
            
            this.txtCategorySales_Apr.AdvancedAnchor = new Firefly.Box.UI.AdvancedAnchor(0, 100, 0, 0);
            this.txtCategorySales_Apr.Alignment = System.Drawing.ContentAlignment.MiddleRight;
            this.txtCategorySales_Apr.Location = new System.Drawing.Point(2, 2);
            this.txtCategorySales_Apr.Name = "txtCategorySales_Apr";
            this.txtCategorySales_Apr.Size = new System.Drawing.Size(70, 17);
            this.txtCategorySales_Apr.Style = Firefly.Box.UI.ControlStyle.Flat;
            this.txtCategorySales_Apr.Tag = "Apr";
            this.txtCategorySales_Apr.Data = this._controller.CategorySales.Apr;
            
            // gclMay
            
            this.gclMay.Controls.Add(this.txtCategorySales_May);
            this.gclMay.Name = "gclMay";
            this.gclMay.Text = "May";
            this.gclMay.Width = 79;
            
            // txtCategorySales_May
            
            this.txtCategorySales_May.AdvancedAnchor = new Firefly.Box.UI.AdvancedAnchor(0, 100, 0, 0);
            this.txtCategorySales_May.Alignment = System.Drawing.ContentAlignment.MiddleRight;
            this.txtCategorySales_May.Location = new System.Drawing.Point(2, 2);
            this.txtCategorySales_May.Name = "txtCategorySales_May";
            this.txtCategorySales_May.Size = new System.Drawing.Size(70, 17);
            this.txtCategorySales_May.Style = Firefly.Box.UI.ControlStyle.Flat;
            this.txtCategorySales_May.Tag = "May";
            this.txtCategorySales_May.Data = this._controller.CategorySales.May;
            
            // gclJun
            
            this.gclJun.Controls.Add(this.txtCategorySales_Jun);
            this.gclJun.Name = "gclJun";
            this.gclJun.Text = "Jun";
            this.gclJun.Width = 78;
            
            // txtCategorySales_Jun
            
            this.txtCategorySales_Jun.AdvancedAnchor = new Firefly.Box.UI.AdvancedAnchor(0, 100, 0, 0);
            this.txtCategorySales_Jun.Alignment = System.Drawing.ContentAlignment.MiddleRight;
            this.txtCategorySales_Jun.Location = new System.Drawing.Point(2, 2);
            this.txtCategorySales_Jun.Name = "txtCategorySales_Jun";
            this.txtCategorySales_Jun.Size = new System.Drawing.Size(70, 17);
            this.txtCategorySales_Jun.Style = Firefly.Box.UI.ControlStyle.Flat;
            this.txtCategorySales_Jun.Tag = "Jun";
            this.txtCategorySales_Jun.Data = this._controller.CategorySales.Jun;
            
            // gclJul
            
            this.gclJul.Controls.Add(this.txtCategorySales_Jul);
            this.gclJul.Name = "gclJul";
            this.gclJul.Text = "Jul";
            this.gclJul.Width = 79;
            
            // txtCategorySales_Jul
            
            this.txtCategorySales_Jul.AdvancedAnchor = new Firefly.Box.UI.AdvancedAnchor(0, 100, 0, 0);
            this.txtCategorySales_Jul.Alignment = System.Drawing.ContentAlignment.MiddleRight;
            this.txtCategorySales_Jul.Location = new System.Drawing.Point(2, 2);
            this.txtCategorySales_Jul.Name = "txtCategorySales_Jul";
            this.txtCategorySales_Jul.Size = new System.Drawing.Size(70, 17);
            this.txtCategorySales_Jul.Style = Firefly.Box.UI.ControlStyle.Flat;
            this.txtCategorySales_Jul.Tag = "Jul";
            this.txtCategorySales_Jul.Data = this._controller.CategorySales.Jul;
            
            // gclAug
            
            this.gclAug.Controls.Add(this.txtCategorySales_Aug);
            this.gclAug.Name = "gclAug";
            this.gclAug.Text = "Aug";
            this.gclAug.Width = 79;
            
            // txtCategorySales_Aug
            
            this.txtCategorySales_Aug.AdvancedAnchor = new Firefly.Box.UI.AdvancedAnchor(0, 100, 0, 0);
            this.txtCategorySales_Aug.Alignment = System.Drawing.ContentAlignment.MiddleRight;
            this.txtCategorySales_Aug.Location = new System.Drawing.Point(2, 2);
            this.txtCategorySales_Aug.Name = "txtCategorySales_Aug";
            this.txtCategorySales_Aug.Size = new System.Drawing.Size(70, 17);
            this.txtCategorySales_Aug.Style = Firefly.Box.UI.ControlStyle.Flat;
            this.txtCategorySales_Aug.Tag = "Aug";
            this.txtCategorySales_Aug.Data = this._controller.CategorySales.Aug;
            
            // gclSep
            
            this.gclSep.Controls.Add(this.txtCategorySales_Sep);
            this.gclSep.Name = "gclSep";
            this.gclSep.Text = "Sep";
            this.gclSep.Width = 79;
            
            // txtCategorySales_Sep
            
            this.txtCategorySales_Sep.AdvancedAnchor = new Firefly.Box.UI.AdvancedAnchor(0, 100, 0, 0);
            this.txtCategorySales_Sep.Alignment = System.Drawing.ContentAlignment.MiddleRight;
            this.txtCategorySales_Sep.Location = new System.Drawing.Point(2, 2);
            this.txtCategorySales_Sep.Name = "txtCategorySales_Sep";
            this.txtCategorySales_Sep.Size = new System.Drawing.Size(70, 17);
            this.txtCategorySales_Sep.Style = Firefly.Box.UI.ControlStyle.Flat;
            this.txtCategorySales_Sep.Tag = "Sep";
            this.txtCategorySales_Sep.Data = this._controller.CategorySales.Sep;
            
            // gclOct
            
            this.gclOct.Controls.Add(this.txtCategorySales_Oct);
            this.gclOct.Name = "gclOct";
            this.gclOct.Text = "Oct";
            this.gclOct.Width = 78;
            
            // txtCategorySales_Oct
            
            this.txtCategorySales_Oct.AdvancedAnchor = new Firefly.Box.UI.AdvancedAnchor(0, 100, 0, 0);
            this.txtCategorySales_Oct.Alignment = System.Drawing.ContentAlignment.MiddleRight;
            this.txtCategorySales_Oct.Location = new System.Drawing.Point(2, 2);
            this.txtCategorySales_Oct.Name = "txtCategorySales_Oct";
            this.txtCategorySales_Oct.Size = new System.Drawing.Size(70, 17);
            this.txtCategorySales_Oct.Style = Firefly.Box.UI.ControlStyle.Flat;
            this.txtCategorySales_Oct.Tag = "Oct";
            this.txtCategorySales_Oct.Data = this._controller.CategorySales.Oct;
            
            // gclNov
            
            this.gclNov.Controls.Add(this.txtCategorySales_Nov);
            this.gclNov.Name = "gclNov";
            this.gclNov.Text = "Nov";
            this.gclNov.Width = 79;
            
            // txtCategorySales_Nov
            
            this.txtCategorySales_Nov.AdvancedAnchor = new Firefly.Box.UI.AdvancedAnchor(0, 100, 0, 0);
            this.txtCategorySales_Nov.Alignment = System.Drawing.ContentAlignment.MiddleRight;
            this.txtCategorySales_Nov.Location = new System.Drawing.Point(2, 2);
            this.txtCategorySales_Nov.Name = "txtCategorySales_Nov";
            this.txtCategorySales_Nov.Size = new System.Drawing.Size(70, 17);
            this.txtCategorySales_Nov.Style = Firefly.Box.UI.ControlStyle.Flat;
            this.txtCategorySales_Nov.Tag = "Nov";
            this.txtCategorySales_Nov.Data = this._controller.CategorySales.Nov;
            
            // gclDec
            
            this.gclDec.Controls.Add(this.txtCategorySales_Dec);
            this.gclDec.Name = "gclDec";
            this.gclDec.Text = "Dec";
            this.gclDec.Width = 79;
            
            // txtCategorySales_Dec
            
            this.txtCategorySales_Dec.AdvancedAnchor = new Firefly.Box.UI.AdvancedAnchor(0, 100, 0, 0);
            this.txtCategorySales_Dec.Alignment = System.Drawing.ContentAlignment.MiddleRight;
            this.txtCategorySales_Dec.Location = new System.Drawing.Point(2, 2);
            this.txtCategorySales_Dec.Name = "txtCategorySales_Dec";
            this.txtCategorySales_Dec.Size = new System.Drawing.Size(70, 17);
            this.txtCategorySales_Dec.Style = Firefly.Box.UI.ControlStyle.Flat;
            this.txtCategorySales_Dec.Tag = "Dec";
            this.txtCategorySales_Dec.Data = this._controller.CategorySales.Dec;
            
            // CategorySalesInfoBrowse_CategorySales
            
            this.AutoScaleDimensions = new System.Drawing.SizeF(5F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Border = Firefly.Box.UI.ControlBorderStyle.None;
            this.ClientSize = new System.Drawing.Size(1088, 317);
            this.Controls.Add(this.grd);
            this.FitToMDI = true;
            this.HorizontalExpressionFactor = 4D;
            this.HorizontalScale = 5D;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "CategorySalesInfoBrowse_CategorySales";
            this.Text = "Browse - CategorySales";
            this.VerticalExpressionFactor = 8D;
            this.VerticalScale = 13D;
            this.grd.ResumeLayout(false);
            this.gclYear.ResumeLayout(false);
            this.gclCategoryID.ResumeLayout(false);
            this.gclJan.ResumeLayout(false);
            this.gclFeb.ResumeLayout(false);
            this.gclMar.ResumeLayout(false);
            this.gclApr.ResumeLayout(false);
            this.gclMay.ResumeLayout(false);
            this.gclJun.ResumeLayout(false);
            this.gclJul.ResumeLayout(false);
            this.gclAug.ResumeLayout(false);
            this.gclSep.ResumeLayout(false);
            this.gclOct.ResumeLayout(false);
            this.gclNov.ResumeLayout(false);
            this.gclDec.ResumeLayout(false);
            this.ResumeLayout(false);

        }
    }
}
