﻿using Firefly.Box;
using ENV.Data;
using ENV;
using Firefly.Box.Flow;
namespace Northwind
{
    /// <summary>Category Sales Info(P#13)</summary>
    /// <remark>Last change before Migration: 02/07/2017 21:09:05</remark>
    internal class CategorySalesInfo : BusinessProcessBase 
    {
        #region Columns
        readonly NumberColumn start = new NumberColumn("start", "15");
        #endregion
        public CategorySalesInfo()
        {
            Title = "Category Sales Info";
            InitializeDataView();
        }
        void InitializeDataView()
        {
            #region Column Selection
            Columns.Add(start);
            #endregion
        }
        /// <summary>Category Sales Info(P#13)</summary>
        public void Run()
        {
            Execute();
        }
        protected override void OnLoad()
        {
            Exit(ExitTiming.BeforeRow);
            TransactionScope = TransactionScopes.Task;
            AllowUserAbort = true;
        }
        protected override void OnStart()
        {
            start.Value = u.mTime();
            Cached<Delete1>().Run();
            Cached<CollectOrderDetails>().Run();
            Message.ShowWarning(u.Str((u.mTime() - start) / 1000, "3.3"));
            new Browse_CategorySales().Run();
        }
        /// <summary>Delete(P#13.1)</summary>
        /// <remark>Last change before Migration: 02/07/2017 08:55:56</remark>
        class Delete1 : BusinessProcessBase 
        {
            #region Models
            readonly Models.CategorySales CategorySales = new Models.CategorySales { AllowRowLocking = true };
            #endregion
            public Delete1()
            {
                Title = "Delete";
                InitializeDataView();
            }
            void InitializeDataView()
            {
                From = CategorySales;
                Columns.Add(From.PrimaryKeyColumns);
                OrderBy = CategorySales.SortByYearAndCategory;
            }
            /// <summary>Delete(P#13.1)</summary>
            internal void Run()
            {
                Execute();
            }
            protected override void OnLoad()
            {
                RowLocking = LockingStrategy.OnRowLoading;
                TransactionScope = TransactionScopes.Task;
                Activity = Activities.Delete;
                AllowUserAbort = true;
            }
        }
        /// <summary>Collect Order Details(P#13.2)</summary>
        /// <remark>Last change before Migration: 02/07/2017 09:06:51</remark>
        class CollectOrderDetails : BusinessProcessBase 
        {
            #region Models
            readonly Models.Order_Details Order_Details = new Models.Order_Details { AllowRowLocking = true };
            readonly Models.Products Products = new Models.Products { AllowRowLocking = true };
            readonly Models.Orders Orders = new Models.Orders { ReadOnly = true };
            readonly Models.ExchangeRates ExchangeRates = new Models.ExchangeRates { ReadOnly = true };
            readonly Models.CategorySales CategorySales = new Models.CategorySales { AllowRowLocking = true };
            #endregion
            #region Columns
            readonly Types.Amount RowTotal = new Types.Amount { Caption = "RowTotal" };
            #endregion
            public CollectOrderDetails()
            {
                Title = "Collect Order Details";
                InitializeDataView();
            }
            void InitializeDataView()
            {
                From = Order_Details;
                
                #region Relations
                Relations.Add(Products, Products.ProductID.IsEqualTo(Order_Details.ProductID), Products.SortByPK_Products);
                
                Relations.Add(Orders, Orders.OrderID.IsEqualTo(Order_Details.OrderID), Orders.SortByPK_Orders);
                
                Relations.Add(ExchangeRates, ExchangeRates.Currency.IsEqualTo("USD").And(
                		ExchangeRates.EffectiveDate.IsLessOrEqualTo(Orders.OrderDate)), 
                	ExchangeRates.SortByDate);
                Relations[ExchangeRates].OrderBy.Reversed = true;
                
                Relations.Add(CategorySales, RelationType.InsertIfNotFound, CategorySales.Year.BindEqualTo(() => u.Year(Orders.OrderDate)).And(
                		CategorySales.CategoryID.BindEqualTo(Products.CategoryID)), 
                	CategorySales.SortByYearAndCategory);
                #endregion
                
                OrderBy = Order_Details.SortByPK_Order_Details;
                #region Column Selection
                Columns.Add(Order_Details.OrderID);
                Columns.Add(Order_Details.ProductID);
                Columns.Add(Order_Details.UnitPrice);
                Columns.Add(Order_Details.Quantity);
                Columns.Add(Products.ProductID);
                Columns.Add(Products.CategoryID);
                Columns.Add(Orders.OrderID);
                Columns.Add(Orders.OrderDate);
                Columns.Add(ExchangeRates.Currency);
                Columns.Add(ExchangeRates.EffectiveDate);
                Columns.Add(ExchangeRates.Rate);
                Columns.Add(CategorySales.Year);
                Columns.Add(CategorySales.CategoryID);
                Columns.Add(CategorySales.Jan);
                Columns.Add(CategorySales.Feb);
                Columns.Add(CategorySales.Mar);
                Columns.Add(CategorySales.Apr);
                Columns.Add(CategorySales.May);
                Columns.Add(CategorySales.Jun);
                Columns.Add(CategorySales.Jul);
                Columns.Add(CategorySales.Aug);
                Columns.Add(CategorySales.Sep);
                Columns.Add(CategorySales.Oct);
                Columns.Add(CategorySales.Nov);
                Columns.Add(CategorySales.Dec);
                Columns.Add(RowTotal);
                #endregion
            }
            /// <summary>Collect Order Details(P#13.2)</summary>
            internal void Run()
            {
                Execute();
            }
            protected override void OnLoad()
            {
                RowLocking = LockingStrategy.OnRowLoading;
                TransactionScope = TransactionScopes.Task;
                AllowUserAbort = true;
            }
            protected override void OnLeaveRow()
            {
                RowTotal.Value = Order_Details.UnitPrice * Order_Details.Quantity * ExchangeRates.Rate;
                
                if (u.Month(Orders.OrderDate) == 1)
                    CategorySales.Jan.Value += RowTotal;
                if (u.Month(Orders.OrderDate) == 2)
                    CategorySales.Feb.Value += RowTotal;
                if (u.Month(Orders.OrderDate) == 3)
                    CategorySales.Mar.Value += RowTotal;
                if (u.Month(Orders.OrderDate) == 4)
                    CategorySales.Apr.Value += RowTotal;
                if (u.Month(Orders.OrderDate) == 5)
                    CategorySales.May.Value += RowTotal;
                if (u.Month(Orders.OrderDate) == 6)
                    CategorySales.Jun.Value += RowTotal;
                if (u.Month(Orders.OrderDate) == 7)
                    CategorySales.Jul.Value += RowTotal;
                if (u.Month(Orders.OrderDate) == 8)
                    CategorySales.Aug.Value += RowTotal;
                if (u.Month(Orders.OrderDate) == 9)
                    CategorySales.Sep.Value += RowTotal;
                if (u.Month(Orders.OrderDate) == 10)
                    CategorySales.Oct.Value += RowTotal;
                if (u.Month(Orders.OrderDate) == 11)
                    CategorySales.Nov.Value += RowTotal;
                if (u.Month(Orders.OrderDate) == 12)
                    CategorySales.Dec.Value += RowTotal;
            }
        }
        /// <summary>Browse - CategorySales(P#13.3)</summary>
        /// <remark>Last change before Migration: 02/07/2017 21:08:49</remark>
        internal class Browse_CategorySales : UIControllerBase 
        {
            #region Models
            internal readonly Models.CategorySales CategorySales = new Models.CategorySales { Cached = true, AllowRowLocking = true };
            #endregion
            public Browse_CategorySales()
            {
                Title = "Browse - CategorySales";
                InitializeDataView();
            }
            void InitializeDataView()
            {
                From = CategorySales;
                OrderBy = CategorySales.SortByYearAndCategory;
                #region Column Selection
                Columns.Add(CategorySales.Year);
                Columns.Add(CategorySales.CategoryID);
                Columns.Add(CategorySales.Jan);
                Columns.Add(CategorySales.Feb);
                Columns.Add(CategorySales.Mar);
                Columns.Add(CategorySales.Apr);
                Columns.Add(CategorySales.May);
                Columns.Add(CategorySales.Jun);
                Columns.Add(CategorySales.Jul);
                Columns.Add(CategorySales.Aug);
                Columns.Add(CategorySales.Sep);
                Columns.Add(CategorySales.Oct);
                Columns.Add(CategorySales.Nov);
                Columns.Add(CategorySales.Dec);
                #endregion
            }
            /// <summary>Browse - CategorySales(P#13.3)</summary>
            internal void Run()
            {
                Execute();
            }
            protected override void OnLoad()
            {
                RowLocking = LockingStrategy.OnRowSaving;
                Activity = Activities.Browse;
                View = () => new Views.CategorySalesInfoBrowse_CategorySales(this);
            }
        }
    }
}
