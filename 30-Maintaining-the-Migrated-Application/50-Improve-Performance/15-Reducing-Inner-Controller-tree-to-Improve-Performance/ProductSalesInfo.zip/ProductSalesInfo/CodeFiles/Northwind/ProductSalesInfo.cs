﻿using Firefly.Box;
using ENV.Data;
using ENV;
using Firefly.Box.Flow;
using Firefly.Box.Advanced;
namespace Northwind
{
    /// <summary>Product Sales Info(P#13)</summary>
    /// <remark>Last change before Migration: 07/08/2017 14:21:57</remark>
    internal class ProductSalesInfo : UIControllerBase 
    {
        #region Columns
        internal readonly TextColumn Country = new TextColumn("Country", "20");
        internal readonly DateColumn FromDate = new DateColumn("From Date", "##/##/####Z");
        internal readonly DateColumn ToDate = new DateColumn("To Date", "##/##/####Z");
        readonly NumberColumn start = new NumberColumn("start", "15");
        #endregion
        #region CustomCommands
        internal readonly CustomCommand Display = new CustomCommand("Display") { Precondition = CustomCommandPrecondition.SaveControlDataToColumn };
        #endregion
        public ProductSalesInfo()
        {
            Title = "Product Sales Info";
            InitializeDataView();
            InitializeHandlers();
        }
        void InitializeDataView()
        {
            #region Column Selection
            Columns.Add(Country);
            Columns.Add(FromDate).BindValue(() => Date.Empty);
            Columns.Add(ToDate).BindValue(() => u.ToDate(u.If(FromDate == Date.Empty, 0, u.ToNumber(u.EOY(FromDate)))));
            Columns.Add(start);
            #endregion
        }
        /// <summary>Product Sales Info(P#13)</summary>
        public void Run()
        {
            Execute();
        }
        protected override void OnLoad()
        {
            RowLocking = LockingStrategy.OnRowSaving;
            View = () => new Views.ProductSalesInfoView(this);
        }
        void InitializeHandlers()
        {
            Handlers.Add(Display).Invokes += e => 
            #region
            {
                u.DBDel(typeof(Models.ProductSalesInfo), "");
                start.SilentSet(u.mTime());
                Cached<CollectData>().Run();
                start.SilentSet(u.mTime() - start);
                new DisplayData(this).Run();
                
                e.Handled = true;
            };
            #endregion
        }
        /// <summary>Collect Data(P#13.1)</summary>
        /// <remark>Last change before Migration: 07/08/2017 12:13:51</remark>
        class CollectData : BusinessProcessBase 
        {
            #region Models
            readonly Models.Customers Customers = new Models.Customers ();
            #endregion
            ProductSalesInfo _parent;
            public CollectData(ProductSalesInfo parent)
            {
                _parent = parent;
                Title = "Collect Data";
                InitializeDataView();
            }
            void InitializeDataView()
            {
                From = Customers;
                Where.Add(CndRange(() => _parent.Country != "", Customers.Country.IsEqualTo(_parent.Country)));
                
                OrderBy = Customers.SortByPK_Customers;
                #region Column Selection
                Columns.Add(Customers.CustomerID);
                Columns.Add(Customers.Country);
                #endregion
            }
            /// <summary>Collect Data(P#13.1)</summary>
            internal void Run()
            {
                Execute();
            }
         
            protected override void OnLeaveRow()
            {
                Cached<CollectOrders>().Run();
            }
            /// <summary>CollectOrders(P#13.1.1)</summary>
            /// <remark>Last change before Migration: 07/08/2017 12:13:58</remark>
            class CollectOrders : BusinessProcessBase 
            {
                #region Models
                readonly Models.Orders Orders = new Models.Orders ();
                #endregion
                CollectData _parent;
                public CollectOrders(CollectData parent)
                {
                    _parent = parent;
                    Title = "CollectOrders";
                    InitializeDataView();
                }
                void InitializeDataView()
                {
                    From = Orders;
                    Where.Add(Orders.CustomerID.IsEqualTo(_parent.Customers.CustomerID));
                    Where.Add(CndRangeBetween(Orders.OrderDate, () => _parent._parent.FromDate != Date.Empty, _parent._parent.FromDate, () => _parent._parent.ToDate != Date.Empty, _parent._parent.ToDate));
                    
                    OrderBy = Orders.SortByCustomerID;
                    #region Column Selection
                    Columns.Add(Orders.OrderID);
                    Columns.Add(Orders.CustomerID);
                    Columns.Add(Orders.OrderDate);
                    #endregion
                }
                /// <summary>CollectOrders(P#13.1.1)</summary>
                internal void Run()
                {
                    Execute();
                }
             
                protected override void OnLeaveRow()
                {
                    Cached<CollectOrderDetails>().Run();
                }
                /// <summary>CollectOrder Details(P#13.1.1.1)</summary>
                /// <remark>Last change before Migration: 07/08/2017 12:15:39</remark>
                class CollectOrderDetails : BusinessProcessBase 
                {
                    #region Models
                    readonly Models.Order_Details Order_Details = new Models.Order_Details ();
                    readonly Models.ProductSalesInfo ProductSalesInfo1 = new Models.ProductSalesInfo ();
                    #endregion
                    CollectOrders _parent;
                    public CollectOrderDetails(CollectOrders parent)
                    {
                        _parent = parent;
                        Title = "CollectOrder Details";
                        InitializeDataView();
                    }
                    void InitializeDataView()
                    {
                        From = Order_Details;
                        
                        Relations.Add(ProductSalesInfo1, RelationType.InsertIfNotFound, ProductSalesInfo1.ProdID.BindEqualTo(Order_Details.ProductID), ProductSalesInfo1.SortByProdID);
                        
                        Where.Add(Order_Details.OrderID.IsEqualTo(_parent.Orders.OrderID));
                        
                        OrderBy = Order_Details.SortByPK_Order_Details;
                        #region Column Selection
                        Columns.Add(Order_Details.OrderID);
                        Columns.Add(Order_Details.ProductID);
                        Columns.Add(Order_Details.UnitPrice);
                        Columns.Add(Order_Details.Quantity);
                        Columns.Add(Order_Details.Discount);
                        Columns.Add(ProductSalesInfo1.ProdID);
                        Columns.Add(ProductSalesInfo1.Quantity);
                        Columns.Add(ProductSalesInfo1.Amount);
                        #endregion
                    }
                    /// <summary>CollectOrder Details(P#13.1.1.1)</summary>
                    internal void Run()
                    {
                        Execute();
                    }
                    protected override void OnLeaveRow()
                    {
                        ProductSalesInfo1.Quantity.Value += Order_Details.Quantity;
                        ProductSalesInfo1.Amount.Value += Order_Details.UnitPrice * Order_Details.Quantity;
                    }
                }
            }
        }
        /// <summary>Display Data(P#13.2)</summary>
        /// <remark>Last change before Migration: 07/08/2017 14:21:57</remark>
        internal class DisplayData : UIControllerBase 
        {
            #region Models
            internal readonly Models.ProductSalesInfo ProductSalesInfo1 = new Models.ProductSalesInfo { AllowRowLocking = true };
            #endregion
            ProductSalesInfo _parent;
            public DisplayData(ProductSalesInfo parent)
            {
                _parent = parent;
                Title = "Display Data";
                InitializeDataView();
            }
            void InitializeDataView()
            {
                From = ProductSalesInfo1;
                OrderBy = ProductSalesInfo1.SortByProdID;
                #region Column Selection
                Columns.Add(ProductSalesInfo1.ProdID);
                Columns.Add(ProductSalesInfo1.Quantity);
                Columns.Add(ProductSalesInfo1.Amount);
                #endregion
            }
            /// <summary>Display Data(P#13.2)</summary>
            internal void Run()
            {
                Execute();
            }
            protected override void OnLoad()
            {
                View = () => new Views.ProductSalesInfoDisplayData(this);
            }
            #region Expressions
            internal Text Exp_1() => "Collected in " + u.MTStr(_parent.start, "HH:MM:SS.mmm");
            
            #endregion
        }
    }
}
