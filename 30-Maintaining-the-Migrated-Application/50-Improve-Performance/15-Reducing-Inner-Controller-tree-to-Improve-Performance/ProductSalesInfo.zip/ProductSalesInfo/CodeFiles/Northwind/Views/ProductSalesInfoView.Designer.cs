﻿using Firefly.Box.UI;
using System.Drawing;
using Firefly.Box.UI.Advanced;
using Firefly.Box;
using Northwind.Shared.Theme;
namespace Northwind.Views
{
    partial class ProductSalesInfoView
    {
        System.ComponentModel.IContainer components;
        Shared.Theme.Controls.CompatibleLabel lblCountry;
        Shared.Theme.Controls.CompatibleTextBox txtCountry;
        Shared.Theme.Controls.CompatibleLabel lblFromDate;
        Shared.Theme.Controls.CompatibleTextBox txtFromDate;
        Shared.Theme.Controls.CompatibleLabel lblToDate;
        Shared.Theme.Controls.CompatibleTextBox txtToDate;
        Shared.Theme.Controls.Button btnDisplay;
        Shared.Theme.Fonts.DefaultDialogText fntDefaultDialogText;
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }
        void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            this.fntDefaultDialogText = new Northwind.Shared.Theme.Fonts.DefaultDialogText();
            this.lblCountry = new Northwind.Shared.Theme.Controls.CompatibleLabel();
            this.txtCountry = new Northwind.Shared.Theme.Controls.CompatibleTextBox();
            this.lblFromDate = new Northwind.Shared.Theme.Controls.CompatibleLabel();
            this.txtFromDate = new Northwind.Shared.Theme.Controls.CompatibleTextBox();
            this.lblToDate = new Northwind.Shared.Theme.Controls.CompatibleLabel();
            this.txtToDate = new Northwind.Shared.Theme.Controls.CompatibleTextBox();
            this.btnDisplay = new Northwind.Shared.Theme.Controls.Button();
            this.SuspendLayout();
            
            // lblCountry
            
            this.lblCountry.FontScheme = this.fntDefaultDialogText;
            this.lblCountry.Location = new System.Drawing.Point(5, 13);
            this.lblCountry.Name = "lblCountry";
            this.lblCountry.Rtf = "Country:";
            this.lblCountry.Size = new System.Drawing.Size(39, 13);
            this.lblCountry.Style = Firefly.Box.UI.ControlStyle.Flat;
            this.lblCountry.Text = "Country:";
            
            // txtCountry
            
            this.txtCountry.Location = new System.Drawing.Point(63, 13);
            this.txtCountry.Name = "txtCountry";
            this.txtCountry.Size = new System.Drawing.Size(143, 16);
            this.txtCountry.Tag = "Country";
            this.txtCountry.Data = this._controller.Country;
            
            // lblFromDate
            
            this.lblFromDate.FontScheme = this.fntDefaultDialogText;
            this.lblFromDate.Location = new System.Drawing.Point(5, 42);
            this.lblFromDate.Name = "lblFromDate";
            this.lblFromDate.Rtf = "From Date:";
            this.lblFromDate.Size = new System.Drawing.Size(53, 13);
            this.lblFromDate.Style = Firefly.Box.UI.ControlStyle.Flat;
            this.lblFromDate.Text = "From Date:";
            
            // txtFromDate
            
            this.txtFromDate.Location = new System.Drawing.Point(63, 42);
            this.txtFromDate.Name = "txtFromDate";
            this.txtFromDate.Size = new System.Drawing.Size(76, 17);
            this.txtFromDate.Tag = "From Date";
            this.txtFromDate.Data = this._controller.FromDate;
            
            // lblToDate
            
            this.lblToDate.FontScheme = this.fntDefaultDialogText;
            this.lblToDate.Location = new System.Drawing.Point(5, 72);
            this.lblToDate.Name = "lblToDate";
            this.lblToDate.Rtf = "To Date:";
            this.lblToDate.Size = new System.Drawing.Size(43, 13);
            this.lblToDate.Style = Firefly.Box.UI.ControlStyle.Flat;
            this.lblToDate.Text = "To Date:";
            
            // txtToDate
            
            this.txtToDate.Location = new System.Drawing.Point(63, 72);
            this.txtToDate.Name = "txtToDate";
            this.txtToDate.Size = new System.Drawing.Size(76, 16);
            this.txtToDate.Tag = "To Date";
            this.txtToDate.Data = this._controller.ToDate;
            
            // btnDisplay
            
            this.btnDisplay.Format = "Display";
            this.btnDisplay.Location = new System.Drawing.Point(310, 91);
            this.btnDisplay.Name = "btnDisplay";
            this.btnDisplay.RaiseClickBeforeFocusChange = true;
            this.btnDisplay.Size = new System.Drawing.Size(80, 23);
            this.btnDisplay.Tag = "display";
            this.btnDisplay.Click += new Firefly.Box.UI.Advanced.ButtonClickEventHandler(this.btnDisplay_Click);
            
            // ProductSalesInfoView
            
            this.AcceptButton = btnDisplay;
            this.AutoScaleDimensions = new System.Drawing.SizeF(5F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(400, 125);
            this.Controls.Add(this.btnDisplay);
            this.Controls.Add(this.txtToDate);
            this.Controls.Add(this.lblToDate);
            this.Controls.Add(this.txtFromDate);
            this.Controls.Add(this.lblFromDate);
            this.Controls.Add(this.txtCountry);
            this.Controls.Add(this.lblCountry);
            this.HorizontalExpressionFactor = 4D;
            this.HorizontalScale = 5D;
            this.Name = "ProductSalesInfoView";
            this.Text = "Product Sales Info";
            this.VerticalExpressionFactor = 8D;
            this.VerticalScale = 13D;
            this.ResumeLayout(false);

        }
    }
}
