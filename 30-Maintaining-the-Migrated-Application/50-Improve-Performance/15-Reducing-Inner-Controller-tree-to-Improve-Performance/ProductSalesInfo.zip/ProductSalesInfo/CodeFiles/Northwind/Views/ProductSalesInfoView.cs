﻿using Firefly.Box.UI;
using System.Drawing;
using Firefly.Box.UI.Advanced;
using Firefly.Box;
using Northwind.Shared.Theme;
namespace Northwind.Views
{
    /// <summary>Product Sales Info(P#13)</summary>
    partial class ProductSalesInfoView : Northwind.Shared.Theme.Controls.CompatibleForm 
    {
        ProductSalesInfo _controller;
        internal ProductSalesInfoView(ProductSalesInfo controller)
        {
            _controller = controller;
            InitializeComponent();
        }
        void btnDisplay_Click(object sender, ButtonClickEventArgs e)
        {
            e.Raise(_controller.Display);
        }
    }
}
