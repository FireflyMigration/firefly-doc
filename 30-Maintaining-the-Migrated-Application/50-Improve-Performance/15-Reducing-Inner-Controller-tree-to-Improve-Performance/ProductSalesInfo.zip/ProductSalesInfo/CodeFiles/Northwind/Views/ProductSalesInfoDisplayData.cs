﻿using Firefly.Box.UI;
using System.Drawing;
using Firefly.Box.UI.Advanced;
using Firefly.Box;
using Northwind.Shared.Theme;
namespace Northwind.Views
{
    /// <summary>Display Data(P#13.2)</summary>
    partial class ProductSalesInfoDisplayData : Northwind.Shared.Theme.Controls.CompatibleForm 
    {
        ProductSalesInfo.DisplayData _controller;
        internal ProductSalesInfoDisplayData(ProductSalesInfo.DisplayData controller)
        {
            _controller = controller;
            InitializeComponent();
        }
        void this_BindText(object sender, StringBindingEventArgs e)
        {
            e.Value = _controller.Exp_1();
        }
    }
}
