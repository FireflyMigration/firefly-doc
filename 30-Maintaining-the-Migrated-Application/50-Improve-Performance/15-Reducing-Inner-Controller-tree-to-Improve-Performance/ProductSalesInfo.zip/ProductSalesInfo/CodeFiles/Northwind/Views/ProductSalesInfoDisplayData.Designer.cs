﻿using Firefly.Box.UI;
using System.Drawing;
using Firefly.Box.UI.Advanced;
using Firefly.Box;
using Northwind.Shared.Theme;
namespace Northwind.Views
{
    partial class ProductSalesInfoDisplayData
    {
        System.ComponentModel.IContainer components;
        Shared.Theme.Controls.CompatibleGrid grd;
        Shared.Theme.Controls.CompatibleGridColumn gclProdID;
        Shared.Theme.Controls.CompatibleGridColumn gclQuantity;
        Shared.Theme.Controls.CompatibleGridColumn gclAmount;
        Shared.Theme.Controls.CompatibleTextBox txtProductSalesInfo1_ProdID;
        Shared.Theme.Controls.CompatibleTextBox txtProductSalesInfo1_Quantity;
        Shared.Theme.Controls.CompatibleTextBox txtProductSalesInfo1_Amount;
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }
        void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            this.grd = new Northwind.Shared.Theme.Controls.CompatibleGrid();
            this.gclProdID = new Northwind.Shared.Theme.Controls.CompatibleGridColumn();
            this.txtProductSalesInfo1_ProdID = new Northwind.Shared.Theme.Controls.CompatibleTextBox();
            this.gclQuantity = new Northwind.Shared.Theme.Controls.CompatibleGridColumn();
            this.txtProductSalesInfo1_Quantity = new Northwind.Shared.Theme.Controls.CompatibleTextBox();
            this.gclAmount = new Northwind.Shared.Theme.Controls.CompatibleGridColumn();
            this.txtProductSalesInfo1_Amount = new Northwind.Shared.Theme.Controls.CompatibleTextBox();
            this.grd.SuspendLayout();
            this.gclProdID.SuspendLayout();
            this.gclQuantity.SuspendLayout();
            this.gclAmount.SuspendLayout();
            this.SuspendLayout();
            
            // grd
            
            this.grd.AdvancedAnchor = new Firefly.Box.UI.AdvancedAnchor(0, 100, 0, 100);
            this.grd.Controls.Add(this.gclProdID);
            this.grd.Controls.Add(this.gclQuantity);
            this.grd.Controls.Add(this.gclAmount);
            this.grd.Location = new System.Drawing.Point(10, 13);
            this.grd.Name = "grd";
            this.grd.RowHeight = 21;
            this.grd.Size = new System.Drawing.Size(240, 296);
            
            // gclProdID
            
            this.gclProdID.AllowSort = true;
            this.gclProdID.Controls.Add(this.txtProductSalesInfo1_ProdID);
            this.gclProdID.Name = "gclProdID";
            this.gclProdID.Text = "Prod ID";
            this.gclProdID.Width = 74;
            
            // txtProductSalesInfo1_ProdID
            
            this.txtProductSalesInfo1_ProdID.AdvancedAnchor = new Firefly.Box.UI.AdvancedAnchor(0, 100, 0, 0);
            this.txtProductSalesInfo1_ProdID.Alignment = System.Drawing.ContentAlignment.MiddleRight;
            this.txtProductSalesInfo1_ProdID.Location = new System.Drawing.Point(3, 2);
            this.txtProductSalesInfo1_ProdID.Name = "txtProductSalesInfo1_ProdID";
            this.txtProductSalesInfo1_ProdID.Size = new System.Drawing.Size(64, 17);
            this.txtProductSalesInfo1_ProdID.Style = Firefly.Box.UI.ControlStyle.Flat;
            this.txtProductSalesInfo1_ProdID.Tag = "Prod ID";
            this.txtProductSalesInfo1_ProdID.Data = this._controller.ProductSalesInfo1.ProdID;
            
            // gclQuantity
            
            this.gclQuantity.Controls.Add(this.txtProductSalesInfo1_Quantity);
            this.gclQuantity.Name = "gclQuantity";
            this.gclQuantity.Text = "Quantity";
            this.gclQuantity.Width = 55;
            
            // txtProductSalesInfo1_Quantity
            
            this.txtProductSalesInfo1_Quantity.AdvancedAnchor = new Firefly.Box.UI.AdvancedAnchor(0, 100, 0, 0);
            this.txtProductSalesInfo1_Quantity.Alignment = System.Drawing.ContentAlignment.MiddleRight;
            this.txtProductSalesInfo1_Quantity.Location = new System.Drawing.Point(2, 2);
            this.txtProductSalesInfo1_Quantity.Name = "txtProductSalesInfo1_Quantity";
            this.txtProductSalesInfo1_Quantity.Size = new System.Drawing.Size(46, 17);
            this.txtProductSalesInfo1_Quantity.Style = Firefly.Box.UI.ControlStyle.Flat;
            this.txtProductSalesInfo1_Quantity.Tag = "Quantity";
            this.txtProductSalesInfo1_Quantity.Data = this._controller.ProductSalesInfo1.Quantity;
            
            // gclAmount
            
            this.gclAmount.Controls.Add(this.txtProductSalesInfo1_Amount);
            this.gclAmount.Name = "gclAmount";
            this.gclAmount.Text = "Amount";
            this.gclAmount.Width = 91;
            
            // txtProductSalesInfo1_Amount
            
            this.txtProductSalesInfo1_Amount.AdvancedAnchor = new Firefly.Box.UI.AdvancedAnchor(0, 100, 0, 0);
            this.txtProductSalesInfo1_Amount.Alignment = System.Drawing.ContentAlignment.MiddleRight;
            this.txtProductSalesInfo1_Amount.Location = new System.Drawing.Point(2, 2);
            this.txtProductSalesInfo1_Amount.Name = "txtProductSalesInfo1_Amount";
            this.txtProductSalesInfo1_Amount.Size = new System.Drawing.Size(82, 17);
            this.txtProductSalesInfo1_Amount.Style = Firefly.Box.UI.ControlStyle.Flat;
            this.txtProductSalesInfo1_Amount.Tag = "Amount";
            this.txtProductSalesInfo1_Amount.Data = this._controller.ProductSalesInfo1.Amount;
            
            // ProductSalesInfoDisplayData
            
            this.AutoScaleDimensions = new System.Drawing.SizeF(5F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(400, 325);
            this.Controls.Add(this.grd);
            this.HorizontalExpressionFactor = 4D;
            this.HorizontalScale = 5D;
            this.Name = "ProductSalesInfoDisplayData";
            this.Text = "Display Data";
            this.VerticalExpressionFactor = 8D;
            this.VerticalScale = 13D;
            this.BindText += new Firefly.Box.UI.Advanced.BindingEventHandler<Firefly.Box.UI.Advanced.StringBindingEventArgs>(this.this_BindText);
            this.grd.ResumeLayout(false);
            this.gclProdID.ResumeLayout(false);
            this.gclQuantity.ResumeLayout(false);
            this.gclAmount.ResumeLayout(false);
            this.ResumeLayout(false);

        }
    }
}
