﻿using Firefly.Box;
using ENV.Data;
namespace Northwind.Models
{
    /// <summary>Product Sales Info(E#9)</summary>
    public class ProductSalesInfo : Entity 
    {
        #region Columns
        [PrimaryKey]
        public readonly Types.ProdID ProdID = new Types.ProdID { Name = "Prod ID" };
        public readonly NumberColumn Quantity = new NumberColumn("Quantity", "N5C");
        public readonly Types.Amount Amount = new Types.Amount { Name = "Amount", Format = "7.2CZ +$;" };
        #endregion
        #region Indexes
        /// <summary>By Prod ID (#1)</summary>
        public readonly Index SortByProdID = new Index { Caption = "By Prod ID", AutoCreate = true, Unique = true };
        #endregion
        public ProductSalesInfo() : base("Product_Sales_Info", "Product Sales Info", Northwind.Shared.DataSources.Memory)
        {
            InitializeIndexes();
        }
        void InitializeIndexes()
        {
            SortByProdID.Add(ProdID);
        }
    }
}
